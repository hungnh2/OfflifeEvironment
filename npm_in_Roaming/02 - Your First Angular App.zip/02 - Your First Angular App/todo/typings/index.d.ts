/// <reference path="globals/core-js/index.d.ts" />
/// <reference path="globals/node/index.d.ts" />
